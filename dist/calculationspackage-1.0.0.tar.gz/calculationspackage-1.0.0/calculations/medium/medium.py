def power(base, exponent):
    print(base ** exponent)

def round(num):
    print(round(num))

