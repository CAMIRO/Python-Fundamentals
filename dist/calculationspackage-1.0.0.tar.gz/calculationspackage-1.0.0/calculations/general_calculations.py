def sum(op1, op2):
    print(op1 + op2)

def subtract(op1, op2):
    print(op1 - op2)

def multiply(op1, op2):
    print(op1 * op2)

def divide(dividend, divider):
    print(dividend / divider)

def power(base, exponent):
    print(base ** exponent)

def round(num):
    print(round(num))

